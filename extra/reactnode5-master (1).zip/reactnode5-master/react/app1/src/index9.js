import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
//class componentss 
class Page extends React.Component
{
    //render method must return html code that you want to display
    render()
    {
        return (<div className='container'>
            <div className='row'>
                <div className='col-12'>
                    <h1>Class components</h1>
                    <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit velit urna, in convallis quam tristique id. Aliquam iaculis dictum odio, in ullamcorper tellus sagittis sed. Sed et nibh mollis est tempor tempus eget non leo. Quisque non lacus id nunc dapibus consequat. Mauris ullamcorper, metus nec vulputate auctor, mauris ex posuere justo, non condimentum orci ante ac purus. Nunc ultricies vulputate dui eget faucibus. Proin convallis varius porttitor. 
                    </p>
                </div>
            </div>
        </div>)
    }
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Page />);
