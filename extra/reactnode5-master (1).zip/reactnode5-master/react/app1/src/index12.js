import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Team from './team';
import IPL from './IPL';
var root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<IPL />);
