import {Outlet,Link} from 'react-router-dom'
var MyMenu = () => {
    return (<div>
        <ul className='nav'>
            <li className='nav-item'>
                <Link className='nav-link' to='/home'>Home</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-link' to='/aboutus'>About us</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-link' to='/products'>Products</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-link' to='/services'>Services</Link>
            </li>
            <li className='nav-item'>
                <Link className='nav-link' to='/contactus'>Contact us</Link>
            </li>
        </ul>
        <Outlet />
    </div>)
}
export default MyMenu