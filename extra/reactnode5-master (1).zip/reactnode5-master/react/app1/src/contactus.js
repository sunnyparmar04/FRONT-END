function Contactus()
{
    return (<h1>Contact us</h1>);
}
export default Contactus