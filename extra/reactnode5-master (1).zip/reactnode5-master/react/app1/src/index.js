import {BrowserRouter,Routes,Route} from 'react-router-dom';
import ReactDOM from 'react-dom/client';
import './index.css';
import MyMenu from './layout';
import Home from './home';
import Aboutus from './aboutus';
import Products from './products';
import Services from './services';
import Contactus from './contactus';
var root = ReactDOM.createRoot(document.getElementById('root'));
function Myapp()
{
    return (<div>
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<MyMenu />} >
                    <Route path='/home' element={<Home />} />
                    <Route path='/aboutus' element={<Aboutus />} />
                    <Route path='/products' element={<Products />} />
                    <Route path='/services' element={<Services />} />
                    <Route path='/contactus' element={<Contactus />} />
                </Route>
            </Routes>
        </BrowserRouter>
    </div>);
}
root.render(<Myapp />);
