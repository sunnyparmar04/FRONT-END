import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
const root = ReactDOM.createRoot(document.getElementById('root'));
var page = (
    <div>
        <h1>React JS Node JS topics</h1>
        <hr />
        <ul>
            <li>HTML</li>
            <li>CSS</li>
            <li>JAVASCRIPT</li>
            <li>Bootstrap</li>
            <li>React JS</li>
            <li>Node JS</li>
            <li>Express JS</li>
            <li>Mysql</li>
            <li>MongoDB</li>
        </ul>
    </div>
)
root.render(page);
