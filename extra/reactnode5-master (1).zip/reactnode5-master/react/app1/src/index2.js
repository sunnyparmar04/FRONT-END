import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
const root = ReactDOM.createRoot(document.getElementById('root'));
var num1 = 20;
var num2 = 3;
var output = <div><h1>Expression in Reactjs</h1><p>Addition = {num1 + num2}</p><p>Substraction = {num1 - num2}</p><p>Multiplication = {num1 * num2}</p><p>Division = {num1/num2}</p></div>
root.render(output);
