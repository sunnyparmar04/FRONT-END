function getBaseAddress()
{
    return `https://www.theeasylearnacademy.com/shop/`;
}
export function getApiBaseAddress()
{
    return getBaseAddress() + `ws/`;
}
export function getImageBaseAddress()
{
    return getBaseAddress() + `images/`;
}