var connection = require('./connection');
var sql = "UPDATE student SET address = 'address' where id = 1";
connection.con.query(sql,function(error,result){

     if(error)
     {
          console.log(error);
     }
     else
     {
          console.log("Affected Rows ",result.affectedRows);
     }
});
connection.con.end();