var connection = require("./connection.js");
var sql = "INSERT into student (name,age,gender,contact_number,address,dob) values ('param',18,1,'9874563210','address','2002-10-02')";
connection.con.query(sql,function(error,result){
     if(error)
     {
          console.log(error);
     }
     else
     {
          console.log("Row inserted Successfully ",result.insertId);
     }
});
connection.con.end();