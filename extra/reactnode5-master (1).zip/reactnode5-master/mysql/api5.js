var connection = require('./connection');
var express = require('express');
var app = express();
var bodypareser = require('body-parser');
var Login_api = require('./login_api5');

app.use(bodypareser.json());
app.use(bodypareser.urlencoded({ 'extended': true }))

app.post('/login',(request, response) => Login_api.Login_api(request,response) );
app.listen(5000);