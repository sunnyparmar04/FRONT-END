var { MongoClient } = require('mongodb');
var express = require('express');
var url = `mongodb://0.0.0.0:27017/reactnode5`;
var client = new MongoClient(url);
var app = express();

app.delete('/student/:name',function(request,response){

     async function main()
     {
          await client.connect(url);
          var db = client.db('reactnode5');
          var collection = db.collection('students');

          let name = request.params.name;
          let search = {'name' : name};
          collection.deleteMany(search).then(function(error,result){
               if(error == true)
               {
                    response.json({'error':error});
               }
               else
               {
                    response.json({'message':'delete Successfully '});
               }
          });
     }
     main();

});
app.listen(5000);