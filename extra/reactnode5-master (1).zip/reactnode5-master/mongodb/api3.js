var { MongoClient } = require('mongodb');
var url = `mongodb://0.0.0.0:27017/reactnode5`;
var client = new MongoClient(url);
var express = require('express');
var app = express();

app.put('/students/:age/:name',function(request,response){

     async function main()
     {
          await client.connect();
          console.log("Connection established ");
          var db = client.db('reactnode5');
          var collection = db.collection('students');

          let age = request.params.age;
          let name = request.params.name;
          let search = { name : 'Param' };
          let data = {$set : {'age' : age} };
          collection.updateMany(search,data).then(function(error,result){
               if(error == true)
               {
                    response.json({'error':error.errmsg});
               }
               else
               {
                    response.json({'message':'Update Successfully '});
               }
          });
     }
     main();
});
app.listen(5000);