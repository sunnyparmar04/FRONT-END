var module5 = require('./mymodule5')
var http = require('http')
var server = http.createServer(function(request,response){

     var p1 = new module5('Param',19);
     p1.Walk();
     p1.GetInfo();
});
server.listen(5000);
console.log("Server Ready...");