var express = require('express');
var bodyparser = require('body-parser');
var app = express();

app.use(bodyparser.urlencoded({'extended':false}));
app.use(bodyparser.json());

app.post('/login',function(request,response){
     console.log("this is login via post ");
     let email = request.body.email ; 
     let password = request.body.password ; 
     console.log("Your email is ",email);
     console.log("Your password is ",password);
     response.send('Login Attempt');
});

app.listen(5000,function(error){
     if(error)
     {
          console.log(error);
     }
     else
     {
          console.log("Server ready ");
     }
});