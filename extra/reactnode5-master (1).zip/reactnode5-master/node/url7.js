// Create a power and exponent clac 
// localhost:5000/power_exponent_calc?power=5&base=2
var http = require('http')
var url = require('url')
var server = http.createServer(function (request, response) {

     var my_url = url.parse(request.url, true);
     console.log(my_url);

     if (my_url.pathname == '/power_exponent_calc') {
          let power = parseInt(my_url.query['power']);
          let base = parseInt(my_url.query['base']);
          console.log("The value of power is ", power, " value of base is ", base);
          let answer = 0;
          let count = 0;
          answer = base * base; // 2 * 2 = 4
          for (count = 2; count < power; count++) {
               answer = answer * base;
          } // 4 * 2 = 8 
          // answer = answer * base; // 8 * 2 = 16
          // answer = answer * base;// 16 * 2 = 32 
          console.log("Answer is ", answer);
     }
});
server.listen(5000);
console.log("Server ready ");