function getCurrentDate()
{
    var date = new Date();
    var currentdate = date.getDate() + "/" + (date.getMonth()+1) + "/" + date.getFullYear();
    return currentdate;
}
function getCurrentTime()
{
    var date = new Date();
    var currenttime = date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
    return currenttime;
}
//export function 
module.exports.getDate = getCurrentDate;
module.exports.getTime = getCurrentTime;
