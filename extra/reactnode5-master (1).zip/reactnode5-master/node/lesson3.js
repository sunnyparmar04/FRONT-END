var http = require('http')
var my = require('./mymodule')
var server = http.createServer(function(request,response){
    var currentdate = my.getDate();
    var currenttime = my.getTime();
    console.log(currentdate);
    console.log(currenttime);
});
var portno = 5000;
server.listen(portno);
console.log('ready to accept request');