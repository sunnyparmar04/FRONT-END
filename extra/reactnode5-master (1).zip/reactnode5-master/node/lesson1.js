function GreetingMessage(name)
{
    console.log('hello ' + name);
    console.log('welcome to world of node JS');
}
var name = 'Ankit Patel';
GreetingMessage(name);``