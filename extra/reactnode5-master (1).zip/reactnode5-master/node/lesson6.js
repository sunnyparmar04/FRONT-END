var http =require("http");
var module4 = require("./mymodule4");
var server = http.createServer(function(request,response){
     console.log(module4.message);
     console.log(module4.port);
     console.log(module4.person);
     console.log("name "+module4.person.name + " age " +module4.person.age + " gender "+module4.person.gender);
});
server.listen(5000);
console.log('Server ready ');