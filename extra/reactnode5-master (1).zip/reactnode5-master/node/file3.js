// Example of writing data into file 
var http = require('http');
var fs = require('fs');
var server = http.createServer(function (request, response) {
     var data = "Pineapple apple chiku ";
     fs.writeFile('fruits.txt', data, function (error) {
          if(error)
          {
               console.log(error);
          }
          else
          {
               console.log("File written successfully ");
          }
     });

});
server.listen(5000);
console.log("Server ready ");