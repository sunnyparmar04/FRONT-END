var http = require('http');
var fs = require('fs');
var buf = new Buffer(1024)
var server = http.createServer(function (request, response) {
     fs.open('fruits.txt', 'r+', function (error, fd) {
          if (error) {
               console.log(error);
          }
          else {
               console.log("file opened successfully ");
               var noofcharater = buf.length;
               fs.read(fd, buf, 0, noofcharater, 0, function (error, count) {
                    if (error) {
                         console.log(error);
                    }
                    else {
                         console.log("total number of charater readed are ", count);
                    }
               });
               fs.close(fd, function (error) {
                    if (error)
                         console.log(error)
                    else {
                         console.log("file closed successfully ");
                    }
               });
          }
     });
});
server.listen(5000);
console.log("Server ready ");