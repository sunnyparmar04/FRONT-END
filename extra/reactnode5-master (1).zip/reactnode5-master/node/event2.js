var events = require('events');
var em = new events.EventEmitter();

em.on('Walk',function(data){
     console.log("i walked "+ data + " meter")
});

em.addListener('Play',function(data){
     console.log("i played "+ data + " hours");
});

em.emit('Walk',100);
em.emit('Play',1.5);