class person
{
     constructor(name,age)
     {
          this.name = name
          this.age = age
     }

     GetInfo() {
          console.log("My name is ",this.name);
          console.log("My age is ",this.age);
     }

     Walk()
     {
          console.log("I can walk ");
     }
}

module.exports = person;