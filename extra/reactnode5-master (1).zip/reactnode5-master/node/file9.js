var http = require('http');
var fs = require('fs')
var server = http.createServer(function(request,response){

     fs.readFile('demo.html',function(error,FileContent){


     });

     fs.appendFile('../myfile.html',FileContent,function(error){
          if(error)
               console.log(error);
          else
               console.log("content appended successfully ");
     })
});
server.listen(5000);
console.log('server ready ');