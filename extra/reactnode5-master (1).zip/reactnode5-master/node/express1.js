var express = require('express');
var app = express();

app.get('/',function(request,response){
     console.log("Home Page called ");
});

app.get('/aboutus',function(request,response){
     console.log("About page called ");
});

app.listen(5000)
console.log("Server Ready ");