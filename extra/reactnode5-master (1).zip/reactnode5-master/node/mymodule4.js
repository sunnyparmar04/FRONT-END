module.exports.message = "Hello world ";
module.exports.port = 5000;
module.exports.person = {
     name : 'Param Patel' ,
     age : 19 ,
     gender : true
}