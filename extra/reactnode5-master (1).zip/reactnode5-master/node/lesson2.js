//import http module
var http = require('http');
//create server that has function which will run when request is received....
var server = http.createServer(function(request,response){
    console.log('we have received new request....');
});

//define port on which request will be send
var portno  = 5000
server.listen(portno);
console.log('ready to accept request.....');