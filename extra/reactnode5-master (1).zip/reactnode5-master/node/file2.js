var http =require('http')
var fs = require('fs')
var server = http.createServer(function(request,response){

     response.writeHead(200,{'content-type':'text/html'});
     var data = fs.readFileSync('../myfile.html');
     response.write(data);
     console.log(data);
     console.log("data readed ");
     response.end();
});
server.listen(5000);
console.log("server ready ");