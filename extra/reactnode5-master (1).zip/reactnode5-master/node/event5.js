var events = require('events');
var em = new events.EventEmitter();

var switchOn = function(data)
{
     console.log("Switch On event called "+ data);
}
var switchOff = function(data)
{
     console.log("Switch Off event called "+data);
}

em.once('switchOnEvent',switchOn);
em.once('switchOffEvent',switchOff);

em.emit('switchOnEvent','Light');
em.emit('switchOnEvent',"PC");

em.emit('switchOffEvent','PC');
em.emit('switchOffEvent','Light');