var http = require("http");
var module2 = require("./mymodule2");
var server = http.createServer(function(request,response){
     module2.info("Hello World ");
     module2.warning("Please start server");
     module2.error("Missing semi colon");
});
server.listen(5000);
console.log("server start ...");