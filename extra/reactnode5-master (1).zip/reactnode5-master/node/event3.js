var events = require('events');
var http = require('http');
var server = http.createServer(function (req, res) {

     var em = new events.EventEmitter();

     var switchOnFunction = function (data) {

          console.log("Switch on event called " + data);
     }

     var switchOffFunction = function (data) {
          console.log("Switch off event called " + data);
     }

     em.on('switchonEvent', switchOnFunction);
     em.on('switchoffEvent', switchOffFunction);

     em.emit('switchonEvent', 'PC');
     em.emit('switchoffEvent', 'PC');
     
     em.removeListener('switchonEvent',switchOnFunction);
     em.emit('switchonEvent', 'Light');
     em.emit('switchoffEvent', 'Light');
});
server.listen(5000)
console.log('Server ready ');