// /aboutus,/contact_us 
var express = require('express');
var app = express();

app.set('view engine','pug');
app.set('views','template');

app.get('/about_us',function(request,response){
     response.render('lesson9');
});

app.get('/contact_us',function(request,response){
     response.render('lesson10');
});
app.listen(5000);
console.log("Server ready ");