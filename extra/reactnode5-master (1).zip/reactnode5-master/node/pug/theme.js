// /aboutus,/contact_us 
var express = require('express');
var app = express();
var path = require('path');

app.set('view engine','pug');
app.set('views','template');
app.use(express.static(path.join(__dirname,'theme')))

app.get('/',function(request,response){
     response.render('home1');
});

app.get('/contact_us',function(request,response){
     response.render('contact_us');
}); 
app.listen(5000);
console.log("Server ready ");