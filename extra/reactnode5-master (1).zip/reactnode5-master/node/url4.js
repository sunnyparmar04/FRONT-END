// 1 - > addition 
// 2 - > subtraction 
// 3 - > multiplication 
// 4 - > divsion 
// 5 - > maximum 
// 6 - > minimum
// 7 -> equality 
var http = require('http');
var url = require('url');
// var math = require('math');
var server = http.createServer(function (request, response) {
     response.writeHead(200,{'content-type':'text-html'});
     var my_url = url.parse(request.url, true);
     // http://localhost:5000/calc?number1=10&number2=20&option=1
     if (my_url.pathname == '/calc') {
          console.log("this is calc");
          let number1 = parseInt(my_url.query['number1']);
          let number2 = parseInt(my_url.query['number2']);
          let option = parseInt(my_url.query['option']);
          let answer = 0;
          if (option == 1) {
               answer = number1 + number2;
          }
          else if (option == 2) {
               answer = number1 - number2;
          }
          else if (option == 3) {
               answer = number1 * number2;
          }
          else if (option == 4) {
               answer = number1 / number2;
          }
          else if (option == 5) {
               answer = Math.max(number1, number2);
          }
          else if (option == 6) {
               answer = Math.min(number1, number2);
          }
          else if (option == 7) {
               if (number1 == number2) {
                    answer = "both are same ";
               }
               else {
                    answer = "both are not same ";
               }
          }
          console.log("asnwer is ", answer);
          response.write(`<html>
                              <head>
                                   <title></title>
                              </head>
                              <body>
                                   <h1>Number 1 is : ${number1}</h1>
                                   <h1>Number 2 is :  ${number2}</h1>
                                   <h1>Answer is :  ${answer}</h1>
                              </body>
                         </html>`)
     }
     response.end();

});
server.listen(5000);
console.log("Server ready ");