var http = require('http');
var events = require('events');
var server = http.createServer(function (request, response) {

     var em = new events.EventEmitter();

     em.on('switchOn', function (data) {
          console.log("Switch on " + data);
     });

     em.addListener('switchOff', (data) => {
          console.log("Switch off " + data);
     });

     em.emit('switchOn','PC');
     em.emit('switchOn', 'Light');
     em.emit('switchOff', 'Light');
     em.emit('switchOff','PC');

});
server.listen(5000);
console.log("Server ready ");