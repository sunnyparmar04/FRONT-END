// Example to read file using readfile function 
var http = require('http')
var fs = require('fs')
var server = http.createServer(function(request,response){

     fs.readFile('temp.html',function(error,filecontent){
          response.writeHead(200,{'content-type':'text/html'});
          response.write(filecontent);
          response.end();
          console.log("Data readed...");
     });
});
server.listen(5000)
console.log("Server ready ");