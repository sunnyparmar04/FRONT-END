var http = require("http");
var module3 = require("./mymodule3");
var server = http.createServer(function(request,response){
     module3.rupeesToDoller(100);
     module3.rupeesToEuro(100);
     module3.rupeestoDirham(100);
});
server.listen(5000);
console.log("Server ready....");