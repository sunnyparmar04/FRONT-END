var express = require('express')
var app = express()

app.use(function (request, response, next) {
     console.log("first middleware called ");
     next();
});

app.use(function (request, response, next) {
     console.log("request method is " + request.method);
     console.log("request url is " + request.url);
     next();
});

// localhost:5000/product/2
// 127.0.0.1:5000/product/2
app.get('/product/:productid/:name', function (request, response) {
     console.log(request.params);
     response.send("product id is " + request.params.productid + "product name is " + request.params.name);
});

app.all('/*',function(request,response){
     console.log("Page not Found ");
     response.send("No Such Page Exsits ");
});

app.listen(5000, function (error) {
     if (error != null)
          console.log(error)
     else
          console.log('Server ready...');
});