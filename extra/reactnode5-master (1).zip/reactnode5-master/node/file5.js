var http = require('http')
var fs = require('fs')
var server = http.createServer(function(request,response){

     fs.appendFileSync('fruits.txt',"\n orange");
     console.log("File Append Succeessfully");
});
server.listen(5000);
console.log("Server Ready ");