var http = require('http');
var server = http.createServer(function(request,response){
     response.writeHead(200,{'content-type':'application/json'})
     var url = request.url ;
     if(url = '/profile')
     {
          var data = {
               name : "Param patel " ,
               age : 19 ,
               weight : 55.55 , 
               gender : true
          }
          var string_data = JSON.stringify(data);
          response.write(string_data);
     }
     response.end();
});
server.listen(5000);
console.log("Server ready ");