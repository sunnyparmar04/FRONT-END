var http = require('http');
var fs = require('fs');
var server = http.createServer(function(request,response){

     fs.unlink('fruits.txt',function(error){
          if(error)
          {
               console.log("File not deleted ");
               console.log(error)
          }
          else
          {
               console.log("File deleted Successfully ");
          }
     });
});
server.listen(5000);
console.log("Server ready ...");